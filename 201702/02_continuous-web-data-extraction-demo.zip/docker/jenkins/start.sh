#!/usr/bin/env bash

#
# Runs the Jenkins server and does some sanity checks first:
#  * Creates a config file for a Jenkins template designed for PHP projects by Sebastian Bergmann.
#  * Creates a slave node named 'php'.
#

file="/var/jenkins_home/jobs/php-template/config.xml"
if [ ! -f "${file}" ]; then
	curl --silent --create-dirs -o ${file} https://raw.githubusercontent.com/sebastianbergmann/php-jenkins-template/master/config.xml

	if [ $? -eq 0 ]; then
    echo "Installing php-jenkins-template succeeded!";
	else
    echo "Installing php-jenkins-template FAILED!";
    exit 255
	fi
else
    echo "Installing php-jenkins-template skipped because already present.";
fi


file="/var/jenkins_home/nodes/php/config.xml"
if [ ! -f "${file}" ]; then
  mkdir -p $(dirname ${file})
	echo "<?xml version='1.0' encoding='UTF-8'?>
<slave>
  <name>php</name>
  <description></description>
  <remoteFS>/</remoteFS>
  <numExecutors>1</numExecutors>
  <mode>NORMAL</mode>
  <retentionStrategy class=\"hudson.slaves.RetentionStrategy\$Always\"/>
  <launcher class=\"hudson.slaves.JNLPLauncher\"/>
  <label>php</label>
  <nodeProperties/>
  <userId>anonymous</userId>
</slave>" > ${file}

	if [ -f "${file}" ]; then
    echo "Installing slave nodes succeeded!";
	else
    echo "Installing slave nodes FAILED!";
    exit 255
	fi
else
    echo "Installing slave node 'php' skipped because already present.";
fi


# run entrypoint command from parent Dockerfile
/bin/tini -- /usr/local/bin/jenkins.sh