#!/bin/sh

#
# This script registers this machine as jenkins-slave
# (from https://wiki.jenkins-ci.org/display/JENKINS/Distributed+builds)
#

master="jenkins:8080"

# load slave
while : ; do
	echo "Trying to retrieve slave.jar from http://${master}/jnlpJars/slave.jar";
	curl --silent --fail --output /slave.jar http://${master}/jnlpJars/slave.jar
	[[ $? != 0 ]] || break

	sleep 5
done

echo "Starting slave agent headlessly";
java -jar /slave.jar -jnlpUrl http://${master}/computer/php/slave-agent.jnlp
