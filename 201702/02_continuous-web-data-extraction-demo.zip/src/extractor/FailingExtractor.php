<?php

namespace extractor;

use Facebook\WebDriver\WebDriverBy;

class FailingExtractor extends BaseExtractor
{
    /**
     * @test
     * @group meh
     */
    public function extract()
    {
        $this->driver->get('https://datatables.net/manual/styling/bootstrap-simple.html');

        // TYPO! -> triggers ElementNotFound
        $this->driver->findElement(WebDriverBy::cssSelector('#exampel'));

        $this->assertTrue(false);
    }
}
