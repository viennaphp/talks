<?php

namespace extractor;

use Facebook\WebDriver\Chrome\ChromeOptions;
use Facebook\WebDriver\Exception\UnexpectedAlertOpenException;
use Facebook\WebDriver\Remote\DesiredCapabilities;
use Facebook\WebDriver\Remote\RemoteWebDriver;
use Facebook\WebDriver\WebDriver;
use Facebook\WebDriver\WebDriverDimension;
use Monolog\Handler\StreamHandler;
use Monolog\Logger;
use PHPUnit\Framework\TestCase;
use PHPUnit\Runner\BaseTestRunner;

abstract class BaseExtractor extends TestCase
{
    protected static $requestTimeoutInMs = 30000;

    /** @var RemoteWebDriver Keep it alive across a test-class to support one login per extractor. */
    private static $staticDriver;

    /** @var array|callable[] */
    private static $postInitCallbacks = array();

    /** @var RemoteWebDriver */
    protected $driver;

    /** @var Logger */
    protected $logger;

    public function __construct()
    {
        parent::__construct();

        $this->logger = new Logger($this->getExtractorName());
        $this->logger->setHandlers(array(
            new StreamHandler('php://stdout')
        ));
    }

    public static function setUpBeforeClass()
    {
        self::$postInitCallbacks = array();

        // setup WebDriver
        $url = 'http://' . SELENIUM_HOST . ':' . SELENIUM_PORT . '/wd/hub';
        $desiredCapabilities = self::getChromeCapabilities();
        self::$staticDriver = RemoteWebDriver::create($url, $desiredCapabilities, 10000, static::$requestTimeoutInMs);

        // reset
        self::$staticDriver->manage()->deleteAllCookies();

        // run post init stuff
        foreach (self::$postInitCallbacks as $postInitCallback) {
            $postInitCallback(self::$staticDriver);
        }
    }

    /**
     * @return DesiredCapabilities
     */
    private static function getChromeCapabilities()
    {
        $options = new ChromeOptions();
        $options->setExperimentalOption('prefs', array('intl.accept_languages' => 'en-gb, en'));

        self::addPostInitCallback(function (WebDriver $webDriver) {
            $webDriver->manage()->window()->setSize(new WebDriverDimension(1280, 1024));
        });

        return $options->toCapabilities();
    }

    protected function setUp()
    {
        $this->driver = self::$staticDriver;
    }

    public function tearDown()
    {
        // take screenshot on errors (ignore passed & skipped tests)
        if (!in_array($this->getStatus(), array(
            BaseTestRunner::STATUS_PASSED,
            BaseTestRunner::STATUS_SKIPPED
        ))
        ) {
            $this->logger->info('Taking screenshot because test finished with status ' . $this->getStatus() . ': ' . $this->getStatusMessage());
            $this->saveScreenshot();
        }

        // and keep driver active
    }

    public static function tearDownAfterClass()
    {
        // clean webdriver
        try {
            if (self::$staticDriver) {
                self::$staticDriver->quit();

                self::$staticDriver = null;
            }
        } catch (\Exception $e) {
            // safely ignore shutdown problems and continue
        }
    }

    private static function addPostInitCallback($callback)
    {
        self::$postInitCallbacks[] = $callback;
    }

    /**
     * "Test Case" - our job to get the data
     */
    abstract public function extract();

    /**
     * @return string Name of the extractor (class name)
     */
    public function getExtractorName()
    {
        $shortClass = substr(strrchr(get_class($this), '\\'), 1);
        return $shortClass;
    }

    protected function saveScreenshot()
    {
        if (!$this->driver) {
            return;
        }

        $target = sprintf(
            '%s/%s_%s.jpg',
            preg_replace('~/src/.*$~', '/build/screenshots', __DIR__),
            date('Y-m-d_H-i-s'),
            preg_replace('~[^a-zA-Z0-9]+~', '_', $this->getExtractorName())
        );

        try {
            $this->driver->takeScreenshot($target);

        } catch (UnexpectedAlertOpenException $e) {
            $this->logger->addError('Failed to take screenshot due to unexpected alert, retrying!');

            try {
                $this->driver->switchTo()->alert()->dismiss();
                $this->saveScreenshot();
                return;
            } catch (\Exception $e) {
                $this->logger->addError('Retry failed: ' . $e->getMessage());
            }

        } catch (\Exception $e) {
            $this->logger->addError('Failed to take screenshot due to: ' . $e->getMessage());
        }
    }

    public function getLogger()
    {
        return $this->logger;
    }
}
