<?php

namespace extractor;

use extractor\helper\DataTables;

/**
 * Uses JavaScript to get the data quickly.
 */
class JsExtractor extends BaseExtractor
{
    /**
     * @test
     * @group foo
     */
    public function extract()
    {
        $this->driver->get('https://datatables.net/manual/styling/bootstrap-simple.html');
        $data = $this->getDataViaJs();

        // do something - put to DB or...
        $this->logger->info(
            sprintf("Got %d rows: %s", count($data), json_encode(array(
                array_splice($data, 0, 1),
                array_splice($data, -1, 1)
            )))
        );

        $this->assertNotEmpty($data);
    }

    public function getDataViaJs()
    {
        $dataTable = new DataTables($this->driver);
        $dataTable->useSelector('#example');

        return $dataTable->getBy(['Name']);
    }
}
