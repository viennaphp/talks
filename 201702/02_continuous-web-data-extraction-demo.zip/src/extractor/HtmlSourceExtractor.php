<?php

namespace extractor;

use Facebook\WebDriver\WebDriverBy;
use Symfony\Component\DomCrawler\Crawler;

class HtmlSourceExtractor extends BaseExtractor
{
    /**
     * @test
     * @group foo
     */
    public function extract()
    {
        $this->driver->get('https://datatables.net/manual/styling/bootstrap-simple.html');
        $data = $this->getDataViaSource();

        // do something - put to DB or...
        $this->logger->info(
            sprintf("Got %d rows: %s", count($data), json_encode(array(
                array_splice($data, 0, 1),
                array_splice($data, -1, 1)
            )))
        );

        $this->assertNotEmpty($data);
    }

    private function getDataViaSource()
    {
        $data = [];
        $columnNames = [];

        $selectors = [
            'th' => '//th',
            'tr' => '//tbody/tr',
            'td' => '//td' // relative to tr
        ];

        $this->foreachPage(function () use ($columnNames, $selectors, &$data) {
            // get source
            $crawler = new Crawler();
            $crawler->addHtmlContent($this->getTableElement()->getAttribute('outerHTML'), 'UTF-8');

            // get column names
            $thElements = $crawler->filterXPath($selectors['th']);
            foreach ($thElements->getIterator() as $thElement) {
                /** @var \DOMElement $thElement */
                $columnNames[] = $thElement->nodeValue;
            }

            // get all table rows
            $trElements = $crawler->filterXPath($selectors['tr']);

            foreach ($trElements->getIterator() as $trElement) {
                /** @var \DOMElement $trElement */
                $trElementCrawler = new Crawler($trElement);

                $index = 0;
                $rowData = [];

                // process all table data within table rows
                $tdElements = $trElementCrawler->filterXPath($selectors['td']);
                foreach ($tdElements->getIterator() as $tdElement) {
                    /** @var \DOMElement $tdElement */
                    $column = $columnNames[$index];

                    $rowData[$column] = $tdElement->nodeValue;
                    $index++;
                }

                $data[$rowData['Name']] = $rowData;
            }
        });

        return $data;
    }

    private function getTableElement()
    {
        return $this->driver->findElement(WebDriverBy::cssSelector('#example'));
    }

    private function foreachPage(Callable $callback)
    {
        do {
            $callback();

            // call for subsequent pages
            $nextButton = $this->driver->findElement(WebDriverBy::cssSelector('.paginate_button.next'));
            $hasNext = strpos($nextButton->getAttribute('class'), 'disabled') === false;

            if ($hasNext) {
                $this->driver->findElement(WebDriverBy::linkText('Next'))->click();
            }
        } while ($hasNext);
    }
}
