<?php

namespace extractor\helper;

use Facebook\WebDriver\Exception\NoSuchElementException;
use Facebook\WebDriver\Remote\RemoteWebDriver;
use Facebook\WebDriver\WebDriverBy;

/**
 * When pages use the DataTables library to present data,
 * we can use its API to query the data in a fast manner.
 *
 * Currently its built upon version 1.9,
 * but support for newer versions could be added if needed.
 *
 * @see http://legacy.datatables.net/api Version 1.9
 * @see https://datatables.net/ Version 1.10
 */
class DataTables
{
    /** @var RemoteWebDriver */
    private $driver;

    /** @var string */
    private $selector;

    /** @var string */
    private $variable;

    /**
     * @param RemoteWebDriver $driver
     */
    public function __construct($driver)
    {
        $this->driver = $driver;
    }

    public function useSelector($selector)
    {
        if ($selector instanceof WebDriverBy) {
            $selector = $selector->getValue();
        }

        $this->selector = $selector;

        $this->verify();
    }

    public function useVariable($variable)
    {
        $this->variable = $variable;

        $this->verify();
    }

    private function verify()
    {
        $dataTableObject = $this->getObjectSelector();

        // (re-)initializes if necessary
        $isMissing = $this->driver->executeScript('return !' . $dataTableObject . ' || ' . $dataTableObject . '.length == 0');
        if ($isMissing) {
            throw new NoSuchElementException('Given selector/variable was not found!');
        }
    }

    /**
     * @param array $columnNamesForIndex
     * @return array
     */
    public function getBy($columnNamesForIndex)
    {
        $data = array();

        $dataTableObject = $this->getObjectSelector();
        $dataRows = $this->driver->executeScript('return ' . $dataTableObject . '.fnGetData();');

        $columnNames = $this->getColumnNames();

        $keyIndexes = array();
        foreach ($columnNamesForIndex as $columnNameForIndex) {
            $foundKey = array_search($columnNameForIndex, $columnNames);
            $keyIndexes[] = $foundKey !== false ? $foundKey : $columnNameForIndex;
        }

        foreach ($dataRows as $dataRow) {
            $key = '';
            foreach ($keyIndexes as $keyIndex) {
                $key .= $dataRow[$keyIndex];
            }

            if (isset($data[$key])) {
                // safeguard
                throw new \DomainException('Overwriting existing row for ' . $key . '. This causes data loss!');
            }

            foreach ($columnNames as $index => $column) {
                $data[$key][$column] = $dataRow[$index];
            }

            // additional data may reside in the $dataRow
            if (count($dataRow) != count($columnNames)) {
                $additionalIndices = array_diff(array_keys($dataRow), array_keys($columnNames));
                foreach ($additionalIndices as $index) {
                    $data[$key][$index] = $dataRow[$index];
                }
            }
        }

        return $data;
    }

    /**
     * @return string
     */
    private function getObjectSelector()
    {
        if ($this->selector) {
            return sprintf('jQuery("%s").dataTable()', $this->selector);

        } else {
            if ($this->variable) {
                return $this->variable;

            } else {
                throw new \BadMethodCallException('Please call useSelector() or useVariable() first!');
            }
        }
    }

    /**
     * @return array
     */
    public function getColumnNames()
    {
        $dataTableObject = $this->getObjectSelector();
        $jsRetrieveHeader = <<<JS
return (function() {
    var columnNames = {};
    {$dataTableObject}.dataTableSettings[0].aoColumns.map(function(aoColumn) {
      // some implementations got numeric keys (Bet365), others got textual ones (NetBet)
      columnNames[aoColumn.mData] = aoColumn.sTitle.trim();
    });
    return columnNames;
})();
JS;
        $columnNames = $this->driver->executeScript($jsRetrieveHeader);

        return array_map(function ($columnName) {
            // keep spaces on line breaks "Text<br>Other" -> "Text Other"
            // remove tags to get rid of <a>-tags
            return strip_tags(str_replace('<br>', ' ', $columnName));
        }, $columnNames);
    }
}