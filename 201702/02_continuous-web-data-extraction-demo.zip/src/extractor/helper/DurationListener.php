<?php

namespace extractor\helper;

use PHPUnit\Framework\AssertionFailedError;
use PHPUnit\Framework\Test;
use PHPUnit\Framework\TestListener;
use PHPUnit\Framework\TestSuite;
use PHPUnit\Framework\Warning;

class DurationListener implements TestListener
{
    public function addError(Test $test, \Exception $e, $time)
    {
        // do nothing
    }

    public function addWarning(Test $test, Warning $e, $time)
    {
        // do nothing
    }

    public function addFailure(Test $test, AssertionFailedError $e, $time)
    {
        // do nothing
    }

    public function addIncompleteTest(Test $test, \Exception $e, $time)
    {
        // do nothing
    }

    public function addRiskyTest(Test $test, \Exception $e, $time)
    {
        // do nothing
    }

    public function addSkippedTest(Test $test, \Exception $e, $time)
    {
        // do nothing
    }

    public function startTestSuite(TestSuite $suite)
    {
        // do nothing
    }

    public function endTestSuite(TestSuite $suite)
    {
        // do nothing
        echo "\n";
    }

    public function startTest(Test $test)
    {
        // do nothing
    }

    public function endTest(Test $test, $time)
    {
        printf("\nTest '%s::%s' ended and took %.2f seconds.\n\n",
            get_class($test),
            $test->getName(),
            $time
        );
    }
}
