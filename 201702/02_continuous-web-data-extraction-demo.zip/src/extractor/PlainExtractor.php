<?php

namespace extractor;

use Facebook\WebDriver\WebDriverBy;

/**
 * Using Selenium way of extracting things.
 */
class PlainExtractor extends BaseExtractor
{
    /**
     * @test
     * @group meh
     */
    public function extract()
    {
        $this->driver->get('https://datatables.net/manual/styling/bootstrap-simple.html');
        $data = $this->getData();

        // do something - put to DB or...
        $this->logger->info(
            sprintf("Got %d rows: %s", count($data), json_encode(array(
                array_splice($data, 0, 1),
                array_splice($data, -1, 1)
            )))
        );

        $this->assertNotEmpty($data);
    }

    public function getData()
    {
        $data = [];
        $columnNames = [];

        $selectors = [
            'th' => WebDriverBy::cssSelector('thead th'),
            'tr' => WebDriverBy::cssSelector('tbody tr'),
            'td' => WebDriverBy::cssSelector('td') // relative to tr
        ];

        // get column names
        $thElements = $this->getTableElement()->findElements($selectors['th']);
        foreach ($thElements as $thElement) {
            $columnNames[] = $thElement->getText();
        }

        // run through all pages
        $this->foreachPage(function () use ($columnNames, $selectors, &$data) {
            $trElements = $this->getTableElement()->findElements($selectors['tr']);
            foreach ($trElements as $trElement) {
                $index = 0;
                $rowData = [];
                $tdElements = $trElement->findElements($selectors['td']);
                foreach ($tdElements as $tdElement) {
                    $column = $columnNames[$index];
                    $rowData[$column] = $tdElement->getText();
                    $index++;
                }

                $data[$rowData['Name']] = $rowData;
            }
        });

        return $data;
    }

    private function foreachPage(Callable $callback)
    {
        do {
            $callback();

            // call for subsequent pages
            $nextButton = $this->driver->findElement(WebDriverBy::cssSelector('.paginate_button.next'));
            $hasNext = strpos($nextButton->getAttribute('class'), 'disabled') === false;

            if ($hasNext) {
                $this->driver->findElement(WebDriverBy::linkText('Next'))->click();
            }
        } while ($hasNext);
    }

    private function getTableElement()
    {
        return $this->driver->findElement(WebDriverBy::cssSelector('#example'));
    }
}
