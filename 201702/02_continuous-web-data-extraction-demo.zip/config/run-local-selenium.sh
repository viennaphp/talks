#!/bin/bash

#
# Description: Starts a headless Selenium server for acceptance testing
# Usage: start-selenium.sh [start|stop] [webserver-port]
#

action=$1
port=$2

# set default action
if [[ ${action} == "" ]];then
	action="start"
fi

if [[ ${port} == "" ]];then
	port="8081"
fi

root_dir=`dirname $(readlink -f $(dirname ${BASH_SOURCE[0]}))`


# check preconditions
if [ -d "/cache" ]; then
  # global cache directory exists (see docker setup)
	selenium_jar="/cache/selenium/selenium-server-standalone.jar"
else
	# no global cache, use project root
	selenium_jar="${root_dir}/selenium-server-standalone.jar"
fi

if [ ! -f ${selenium_jar} ]; then
	echo "Selenium server is missing. Downloading now to: ${selenium_jar}"
	curl -o "${selenium_jar}" -L http://selenium-release.storage.googleapis.com/3.1/selenium-server-standalone-3.1.0.jar

	if [ $? -ne 0 ]; then
		echo "Download failed!"
		echo "See: http://docs.seleniumhq.org/download/"
		exit 1
	fi
else
    echo "Found Selenium server at: ${selenium_jar}"
fi


# helpers
function isRunning() {
	nmap -Pn -p${1} localhost | awk "\$1 ~ /${1}/ {print \$2}" | grep "open" > /dev/null 2>&1

	if [ $? -eq 0 ]; then
    # 0 = true
    return 0
  else
    # 1 = false
    return 1
  fi
}

function stopServer() {
	$(ps -elf | grep -E "(selenium-server-standalone|php -S)" | head -n 50 | awk '{print $4}' | xargs kill)
}

function startServer() {
  echo -ne "Starting Servers (Selenium) "
  java -jar ${selenium_jar} &
}

function init() {
	local isStarting=0
	while :
	do
		isRunning 4444
		is4444Running=$?

		if [ ${is4444Running} -eq 0 ]; then
			break
		elif [ ${isStarting} -eq 0 ]; then
			stopServer

			startServer

			isStarting=1
		fi;

		sleep 0.5
		echo -ne "."
	done;
	echo ""
	echo "Selenium server is running"
}


# run
if [[ ${action} == "start" ]]; then
	init;
elif [[ ${action} == "stop" ]]; then
	stopServer;
fi
