<?php

// receive Selenium host address via Docker environment variable
$host = file_exists('/.dockerenv') ? 'selenium' : '127.0.0.1';
define('SELENIUM_HOST', $host);

// port is the same locally as within Jenkins
define('SELENIUM_PORT', '4444');

// load extractor libs
$classLoader = require_once dirname(__DIR__) . '/vendor/autoload.php';
