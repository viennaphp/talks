# Demo

## Requirements

* Docker 1.10.0+
* Docker-Compose 1.8+
* Chromedriver
  * get it from: http://chromedriver.storage.googleapis.com/index.html?path=2.27/
  * basically move it to `/usr/local/bin/`
  * or see: https://github.com/SeleniumHQ/selenium/wiki/ChromeDriver

## Steps

1. Build Docker images
```
robert@Laptop:~/selenium-demo $ docker-compose build
```

2. Grab a cup of coffee

3. Install dependencies
```
robert@Laptop:~/selenium-demo $ php composer.phar install
```

4. Run extractor locally
```
robert@Laptop:~/selenium-demo $ ant run-local
```

5. Boot Jenkins
```
robert@Laptop:~/selenium-demo $ docker-compose up
```

6. Jenkins

go to: https://localhost:8888/

## Questions/Suggestions

robert@e-2.at
