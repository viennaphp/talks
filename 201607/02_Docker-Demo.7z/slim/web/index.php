<?php

include dirname(__DIR__) . '/vendor/autoload.php';

$app = new Slim\App();

/**
 * Init Redis
 */
try {
    $address = 'tcp://redis:6379?timeout=0.015&async=false';
    $redis = new \Predis\Client($address);
    $redis->connect();
} catch (\Exception $e) {
    throw new \BadMethodCallException(
        'Sorry bro, you cannot use Redis because ' .
        'it was not found on given address "' . $address . '"'
    );
}

$app->get('/', function() use($redis){
    $count = $redis->get('visit_count');
    
    if (empty($count)) {
        $again = '';
        $count = 1;
    } else {
        $again = 'again ';
        if ($count > 1) {
            $again .= '(saw you ' . $count . ' times) ';
        }
    }
    $redis->set('visit_count', ++$count);

    return '<h1>Hello ' . $again . 'ViennaPHP</h1><h2>I\'m Slim 3</h2>';
});

$app->run();
