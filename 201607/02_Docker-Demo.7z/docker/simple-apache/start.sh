#!/bin/bash

http_ip=$(hostname -i)

echo " -----------------------------------------------------------"
echo "| Use the following URLs to access the dockerized webserver:"
echo "|  * http://${http_ip}/"
echo " -----------------------------------------------------------"

function terminate_apache() {
  echo "Terminate Apache WebServer:"
  kill -TERM `cat /usr/local/apache2/logs/httpd.pid`
}

# calling command with exec allows Ctrl+C to terminate Apache
exec apachectl -DFOREGROUND
